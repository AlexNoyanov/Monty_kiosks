<?php
	include_once "../../config/config.php";
	// spl_autoload_register(function ($class_name) {
	//     include $class_name . '.php';
	// });

	class auth{
		public function __construct(){
			echo "test";
		}

		public function index(){
			echo "test";
		}
	}