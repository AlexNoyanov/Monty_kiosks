<?php

    //$connection = mysqli_connect('localhost', 'monty', 'PD8x3weTD');
    $connection = mysqli_connect('localhost', 'root', 'alexnoyanov1999');
    $select_db = mysqli_select_db($connection, 'monty2');
       
?>
