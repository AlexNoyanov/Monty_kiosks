<?php

//Global functions to be used in php files will be listed here