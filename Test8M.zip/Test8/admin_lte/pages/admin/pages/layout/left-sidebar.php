<!-- <?php
  function isActive($menu, $mode="full"){
    global $active_menu;
    //if ($mode == "partial")
    //  echo ($active_menu == $menu? "active": "");
    //else
      echo ($active_menu == $menu? "class='active'": "");
  }
?> -->


      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
