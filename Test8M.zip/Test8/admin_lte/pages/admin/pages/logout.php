<?php

    phpinfo();

    // header("Location: login");

?>